@echo off
title Installing Python Requirements

echo Installing required packages...
py -m pip install --upgrade pip
py -m pip install selenium pandas webdriver-manager

echo.
echo ==========================================
echo Installation Complete!
echo ==========================================
pause