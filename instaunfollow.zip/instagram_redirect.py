import glob
import re
import time
import os
os.system("")
import shutil
import winreg
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException

# ---------- Banner ----------
def show_banner():
    print("\033[95m\033[1m")
    print("""
██╗███╗   ██╗███████╗████████╗ █████╗  ██████╗ ██████╗  █████╗ ███╗   ███╗
██║████╗  ██║██╔════╝╚══██╔══╝██╔══██╗██╔════╝ ██╔══██╗██╔══██╗████╗ ████║
██║██╔██╗ ██║███████╗   ██║   ███████║██║  ███╗██████╔╝███████║██╔████╔██║
██║██║╚██╗██║╚════██║   ██║   ██╔══██║██║   ██║██╔══██╗██╔══██║██║╚██╔╝██║
██║██║ ╚████║███████║   ██║   ██║  ██║╚██████╔╝██║  ██║██║  ██║██║ ╚═╝ ██║
╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝

                 INSTAGRAM UNFOLLOW TOOL
                         by Omie
""")
    print("\033[0m")

show_banner()

# ---------- Automatically Detect the HTML File ----------
matching_files = glob.glob("Instagram_non_followers_*.html")

if not matching_files:
    print("Error: Could not find any file matching 'Instagram_non_followers_*.html' in this folder.")
    exit()

html_file_path = matching_files[0]
print(f"Successfully detected and loading file: {html_file_path}")

try:
    with open(html_file_path, "r", encoding="utf-8") as f:
        html = f.read()
except Exception as e:
    print(f"Error reading file {html_file_path}: {e}")
    exit()

# ---------- Extract Instagram usernames ----------
usernames = re.findall(
    r'https://www\.instagram\.com/([A-Za-z0-9._]+)',
    html
)

# Remove duplicates while preserving list order
usernames = list(dict.fromkeys(usernames))

# Filter out common system paths
ignored_paths = {'p', 'reel', 'stories', 'explore', 'developer'}
usernames = [user for user in usernames if user.lower() not in ignored_paths]

print(f"Found {len(usernames)} unique profiles to process.")

if not usernames:
    print("No usernames found. Exiting.")
    exit()


# ---------- Browser Detection ----------
def find_browser():
    # Check if browser is in PATH
    executables = [
        "chrome.exe",
        "brave.exe",
        "msedge.exe",
        "chromium.exe",
    ]

    for exe in executables:
        path = shutil.which(exe)
        if path:
            return path

    # Common install locations
    common_paths = [
        os.path.expandvars(r"%LOCALAPPDATA%\Chromium\Application\chrome.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\BraveSoftware\Brave-Browser\Application\brave.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),

        r"C:\Program Files\Chromium\Application\chrome.exe",
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",

        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\BraveSoftware\Brave-Browser\Application\brave.exe",
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    ]

    for path in common_paths:
        if os.path.exists(path):
            return path

    # Windows Registry
    registry_keys = [
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe",
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\brave.exe",
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe",
    ]

    for root in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        for key in registry_keys:
            try:
                with winreg.OpenKey(root, key) as reg:
                    browser_path, _ = winreg.QueryValueEx(reg, "")
                    if os.path.exists(browser_path):
                        return browser_path
            except FileNotFoundError:
                pass

    return None


browser_path = find_browser()

if browser_path is None:
    print("❌ No Chromium-based browser found.")
    exit()

print(f"✅ Browser detected:\n{browser_path}")

options = Options()
options.binary_location = browser_path

driver = webdriver.Chrome(options=options)

try:
    # Open Instagram first to let you log in manually
    driver.get("https://www.instagram.com")
    input("Log in to Instagram in the browser window, then press Enter here to continue...")

    # ---------- Open profiles and Unfollow ----------
    for i, username in enumerate(usernames, start=1):
        url = f"https://www.instagram.com/{username}/"
        print(f"\n[{i}/{len(usernames)}] Processing: {url}")

        driver.get(url)
        
        try:
            # 1. Look for and click the 'Following' button on the profile page
            following_xpath = (
                "//button[contains(., 'Following') or contains(., 'Requested')] | "
                "//div[@role='button'][contains(., 'Following') or contains(., 'Requested')]"
            )
            
            following_button = WebDriverWait(driver, 6).until(
                EC.element_to_be_clickable((By.XPATH, following_xpath))
            )
            following_button.click()
            print("   Clicked 'Following' button.")

            # 2. Wait up to 5 seconds, but click immediately when the confirmation button appears
            # This XPath specifically targets the "Unfollow" option inside the popup dialogue overlay
            unfollow_xpath = (
                "//div[@role='dialog']//button[text()='Unfollow' or contains(., 'Unfollow')]"
            )
            
            unfollow_button = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, unfollow_xpath))
            )
            unfollow_button.click()
            print("   Clicked 'Unfollow' in popup. Success!")

            # 3. Micro-cooldown (1 second) to let the page record the action before moving on
            time.sleep(1)

        except TimeoutException:
            print(f"   [Skip] Action element not found for {username}. (Likely already unfollowed or button path shifted).")
        except Exception as e:
            print(f"   [Error] Unexpected issue on {username}: {e}")

finally:
    input("\nFinished! Press Enter in this console window to close the browser...")
    driver.quit()