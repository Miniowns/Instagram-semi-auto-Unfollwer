@echo off
title Instagram Unfollow Tool by Omie

cd /d "%~dp0"

py instagram_redirect.py

echo.
pause