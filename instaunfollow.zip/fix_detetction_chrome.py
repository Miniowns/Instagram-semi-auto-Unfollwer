from selenium import webdriver
from selenium.webdriver.chrome.options import Options

options = Options()
options.binary_location = r"C:\Users\omie\AppData\Local\Chromium\Application\chrome.exe"

# Save login/session
options.add_argument(r"--user-data-dir=C:\Users\omie\selenium_profile")

# Reduce automation fingerprints
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_experimental_option("excludeSwitches", ["enable-automation"])
options.add_experimental_option("useAutomationExtension", False)

driver = webdriver.Chrome(options=options)

# Hide webdriver flag
driver.execute_script(
    "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
)